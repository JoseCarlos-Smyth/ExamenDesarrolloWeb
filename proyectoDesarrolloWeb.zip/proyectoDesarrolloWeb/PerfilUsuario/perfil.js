// Simulación de datos de publicaciones (esto puede provenir de una base de datos o una API)
const postsData = [
    {
        image: 'post1.jpg',
        description: 'Descripción de la publicación 1'
    },
    {
        image: 'post2.jpg',
        description: 'Descripción de la publicación 2'
    },
    // Agrega más datos de publicaciones aquí
];

// Función para mostrar las publicaciones en el perfil del usuario
function mostrarPublicaciones() {
    const userPosts = document.querySelector('.user-posts');

    postsData.forEach(post => {
        const postElement = document.createElement('div');
        postElement.classList.add('post');

        const postImage = document.createElement('img');
        postImage.src = post.image;
        postImage.alt = 'Publicación';
        postElement.appendChild(postImage);

        const postDescription = document.createElement('p');
        postDescription.textContent = post.description;
        postElement.appendChild(postDescription);

        userPosts.appendChild(postElement);
    });
}

// Llama a la función para mostrar las publicaciones cuando la página se cargue
window.addEventListener('load', mostrarPublicaciones);

